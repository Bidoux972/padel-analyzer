import React from "react";
import ReactDOM from "react-dom/client";
import PadelAnalyzer from "./PadelAnalyzer.jsx";

ReactDOM.createRoot(document.getElementById('root')).render(<PadelAnalyzer />);
