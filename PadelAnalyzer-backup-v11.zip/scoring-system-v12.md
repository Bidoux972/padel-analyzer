# PadelAnalyzer V10.4 - Scoring System

## Mechanical Scores (6 axes, 0-10)
- **Puissance**: shape(8/6.5/5.5/4) + balance(+1/+0.5/0/-0.5) + core(+0.5/0/-0.3/-0.8) + surface(+0.5/0/-0.3/-0.8)
- **Contrôle**: shape(5/6.5/7.5/8.5) + balance(-0.5/0/+0.5/+1) + surface(-0.5/0/+0.3/+0.5)
- **Confort**: core(4.5/5.5/6.5/8) + surface(-0.5/0/+0.3/+0.5) + balance(-0.5/0/+0.5/+1)
- **Spin**: texture(6.0 smooth / 7.5 3d / 8.5 rough_3d)
- **Maniabilité**: balance(+2/+1/0/-1) + weight_factor + shape(+1 ronde, +0.5 goutte, 0 hybride, -0.5 diamant)
- **Tolérance**: shape(+1.5/+1/+0.5/0) + surface(+0.5/0/-0.3/-0.5) + core(+0.5/0/-0.3/-0.5)

## Pro Validation Bonuses
- Brand match: +0.25
- Shape preference: +0.20
- Pro-line tier (Motion/Pro/signature): +0.15
- Woman line: +0.20

## Validation Results: 9/9
| Player | Rank | Gap | Racket |
|--------|------|-----|--------|
| Galán | ✅ #1 | 0.000 | Metalbone HRD 2026 |
| Triay | ✅ #1 | 0.000 | Elite Woman 2026 |
| Brea | ✅ #1 | 0.000 | Vertex 05 Woman 2026 |
| Tapia | ≈ #3 | 0.000 | AT10 Genius 12K Xtrem 2026 |
| Paquito | ≈ #2 | 0.156 | Vertex 05 GEO 2026 |
| Coello | ≈ #2 | 0.029 | Coello Pro 2026 |
| Chingotto | ≈ #3 | 0.100 | Vertex 05 Hybrid 2026 |
| Sánchez | ≈ #3 | 0.000 | Speed Motion 2026 |
| Josemaría | ≈ #3 | 0.103 | Extreme Motion 2026 |

## Key Fix: Pro > Motion hierarchy
- Head Extreme Pro 2026: Carbone UD → P:10
- Head Extreme Motion 2026: Carbone/Fibre de verre (hybrid) → P:9
- Head Coello Pro 2026: Carbon Hybrid HS → P:9
- Head Coello Motion 2026: Carbon Hybrid HS → P:8.5
