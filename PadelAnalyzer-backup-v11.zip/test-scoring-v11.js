// Test scoring V11 with realistic profiles
const {
  detectPlayerMode, computeGabaritIndex, computeGlobalScore,
  computeForYou, parseRacketWeight, idealRacketWeight, weightPenalty
} = require("./scoring-v11.js");
const RACKETS = require("./backup-v10.7/rackets-db.json");

function scoreAndRank(profile, label) {
  console.log(`\n${"=".repeat(70)}`);
  console.log(`PROFIL: ${label}`);
  const mode = detectPlayerMode(profile);
  const gab = computeGabaritIndex(profile);
  const idealW = idealRacketWeight(profile, gab);
  console.log(`  Mode: ${mode} | Gabarit: ${gab.toFixed(3)} | Poids idéal raquette: ${idealW.toFixed(0)}g`);
  console.log(`  Genre: ${profile.genre} | Âge: ${profile.age} | ${profile.height}cm/${profile.weight}kg | Fitness: ${profile.fitness} | Level: ${profile.level}`);
  console.log(`  Priorités: ${(profile.priorityTags||[]).join(", ") || "aucune"}`);

  // Score all rackets
  const results = RACKETS.map(r => {
    const scores = r.scores || {};
    const gs = computeGlobalScore(scores, profile, r);
    const fy = computeForYou(scores, profile, r);
    return { name: r.name, brand: r.brand, weight: r.weight, shape: r.shape, cat: r.category, womanLine: r.womanLine, gs, fy };
  }).filter(r => r.gs > 0).sort((a, b) => b.gs - a.gs);

  console.log(`\n  Top 10 (sur ${results.length} éligibles) :`);
  for (let i = 0; i < Math.min(10, results.length); i++) {
    const r = results[i];
    const wl = r.womanLine ? " 👩" : "";
    console.log(`    ${i+1}. ${r.name} (${r.brand}) — ${r.weight} | ${r.shape} | ${r.cat}${wl} → ${(r.gs*10).toFixed(1)}% [${r.fy}]`);
  }

  // Check if womanLine rackets appear for female profiles
  if (profile.genre === "Femme") {
    const wlInTop10 = results.slice(0, 10).filter(r => r.womanLine).length;
    const wlTotal = results.filter(r => r.womanLine).length;
    console.log(`\n  WomanLine: ${wlInTop10}/10 dans le top 10 (${wlTotal} éligibles total)`);
  }

  return results;
}

// =====================
// TEST PROFILES
// =====================

// P6: MANON — Femme avancée, gabarit moyen → doit avoir des raquettes femme
scoreAndRank({
  age: "29", height: "170", weight: "75", genre: "Femme", fitness: "actif",
  level: "Avancé", hand: "Droitier", side: "Droite",
  styleTags: ["tactique"], injuryTags: [], priorityTags: ["controle", "confort"],
  brandTags: [], competition: true,
}, "MANON — Femme 29a 170cm/75kg Avancée Tactique (P6 test)");

// Femme débutante petite — doit voir quasi que du womanLine léger
scoreAndRank({
  age: "35", height: "160", weight: "55", genre: "Femme", fitness: "occasionnel",
  level: "Débutant", hand: "Droitier", side: "Droite",
  styleTags: [], injuryTags: [], priorityTags: ["confort", "legerete"],
  brandTags: [], competition: false,
}, "SOPHIE — Femme 35a 160cm/55kg Débutante (doit être ultra-léger)");

// Femme experte athlétique — mode Tapia femme
scoreAndRank({
  age: "25", height: "175", weight: "65", genre: "Femme", fitness: "athletique",
  level: "Expert", hand: "Droitier", side: "Gauche",
  styleTags: ["offensif", "puissant"], injuryTags: [], priorityTags: ["puissance", "spin"],
  brandTags: ["bullpadel"], competition: true,
}, "ARIANA — Femme 25a 175cm/65kg Expert Athlétique Attaquante (Tapia femme)");

// BIDOU — Homme intermédiaire/avancé avec dos
scoreAndRank({
  age: "49", height: "175", weight: "80", genre: "Homme", fitness: "actif",
  level: "Intermédiaire", hand: "Droitier", side: "Gauche",
  styleTags: ["offensif", "technique"], injuryTags: ["dos"], priorityTags: ["puissance", "confort"],
  brandTags: ["head"], competition: true,
}, "BIDOU — Homme 49a 175cm/80kg Intermédiaire Dos (référence)");

// Expert homme — mode Tapia
scoreAndRank({
  age: "30", height: "185", weight: "82", genre: "Homme", fitness: "athletique",
  level: "Expert", hand: "Droitier", side: "Gauche",
  styleTags: ["offensif", "puissant"], injuryTags: [], priorityTags: ["puissance", "spin"],
  brandTags: ["head"], competition: true,
}, "TAPIA — Homme 30a 185cm/82kg Expert Athlétique Attaquant");

// Junior 12 ans — mode junior pur
scoreAndRank({
  age: "12", height: "150", weight: "40", genre: "Homme", fitness: "actif",
  level: "Débutant", hand: "Droitier", side: "Droite",
  styleTags: [], injuryTags: [], priorityTags: ["confort"],
  brandTags: [], competition: false,
}, "NOAH — Junior 12a 150cm/40kg Débutant");

// Jeune Pépite 14 ans avancé
scoreAndRank({
  age: "14", height: "170", weight: "58", genre: "Homme", fitness: "actif",
  level: "Avancé", hand: "Droitier", side: "Gauche",
  styleTags: ["offensif", "veloce"], injuryTags: [], priorityTags: ["puissance", "spin"],
  brandTags: [], competition: true,
}, "LÉON — Jeune Pépite 14a 170cm/58kg Avancé Actif");

// Senior homme 65 ans — gabarit doit être progressif, pas bridé
scoreAndRank({
  age: "65", height: "178", weight: "85", genre: "Homme", fitness: "actif",
  level: "Avancé", hand: "Droitier", side: "Droite",
  styleTags: ["defensif", "tactique"], injuryTags: ["genou", "dos"], priorityTags: ["confort", "controle"],
  brandTags: [], competition: false,
}, "JEAN-PIERRE — Senior 65a 178cm/85kg Avancé Actif (gabarit progressif, pas bridé)");

console.log("\n" + "=".repeat(70));
console.log("TESTS TERMINÉS");
